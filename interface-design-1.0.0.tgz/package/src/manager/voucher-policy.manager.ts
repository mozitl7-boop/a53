import { IPolicy } from "../policy";
import { IVoucherPolicy } from "../voucher-policy/voucher-policy";

export interface IVoucherPolicyManager {
  /**
   * Tạo chính sách voucher mới
   *
   * @param {IVoucherPolicy} voucherPolicy
   * @return {*}  {IVoucherPolicy}
   * @memberof IVoucherPolicyManager
   */
  createVoucherPolicy(policy: IPolicy, voucherPolicy: IVoucherPolicy): IVoucherPolicy;

  /**
   * Cập nhật chính sách voucher
   *
   * @param {IVoucherPolicy} voucherPolicy
   * @return {*}  {IVoucherPolicy}
   * @memberof IVoucherPolicyManager
   */
  updateVoucherPolicy(voucherPolicy: IVoucherPolicy): IVoucherPolicy;

  /**
   * Get toàn bộ chính sách voucher của 1 policy nào đó
   *
   * @param {number} policyId
   * @return {*}  {IVoucherPolicy[]}
   * @memberof IVoucherPolicyManager
   */
  listVoucherPolicies(policyId: number): IVoucherPolicy[];

  /**
   * Get đối tượng chính sách voucher theo id
   *
   * @param {number} voucherPolicyId
   * @return {*}  {IVoucherPolicy}
   * @memberof IVoucherPolicyManager
   */
  getVoucherPolicy(voucherPolicyId: number): IVoucherPolicy | undefined;

  /**
   * Xóa chính sách voucher
   *
   * @param {IVoucherPolicy} voucherPolicy
   * @memberof IVoucherPolicyManager
   */
  deleteVoucherPolicy(voucherPolicy: IVoucherPolicy): void;
}
