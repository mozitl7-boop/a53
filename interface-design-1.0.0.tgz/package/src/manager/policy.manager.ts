import { IFidtUser } from "../external/fidt-user";
import { IPolicy } from "../policy";

export interface IPolicyManager {
  /**
   * Tạo policy mới bằng tên + upload file chính sách
   *
   * @param {IPolicy} policy
   * @return {*}  {Promise<IPolicy>}
   * @memberof IPolicyManager
   */
  createPolicy(policyName: string, file: any): IPolicy;

  /**
   * Cập nhật thông tin chính sách
   *
   * @param {string} policyName
   * @param {*} file
   * @return {*}  {IPolicy}
   * @memberof IPolicyManager
   */
  updatePolicy(id: number, policyName: string, file: any): IPolicy;

  /**
   * Lấy thông tin chính sách bằng id
   *
   * @param {number} id
   * @return {*}  {IPolicy}
   * @memberof IPolicyManager
   */
  getPolicy(id: number): IPolicy | undefined;

  /**
   * Lấy toàn bộ danh sách chính sách đang có
   *
   * @return {*}  {IPolicy[]}
   * @memberof IPolicyManager
   */
  listAllPolicies(): IPolicy[];
}
