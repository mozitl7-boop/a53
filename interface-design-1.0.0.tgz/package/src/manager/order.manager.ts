import { IOrder } from "../order/order.entity";

export interface IOrderManager {
  /**
   * Tạo order mới, dùng cho event payment thành công tạo order
   *
   * @param {IOrder} order
   * @return {*}  {IOrder}
   * @memberof IOrderManager
   */
  makeOrder(order: IOrder): IOrder;

  /**
   * Cập nhật thông tin đơn hàng
   *
   * @param {IOrder} order
   * @return {*}  {IOrder}
   * @memberof IOrderManager
   */
  updateOrder(order: IOrder): IOrder;

  /**
   * Danh sách toàn bộ order
   *
   * @return {*}  {IOrder[]}
   * @memberof IOrderManager
   */
  listOrders(): IOrder[];
}
