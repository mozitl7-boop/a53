import { IPaymentMethod } from "../external/payment-method";

//stateful
export interface IPaymentMethodManager {
  /**
   * Danh sách toàn bộ phương thức thanh toán
   *
   * @return {*}  {IPaymentMethod[]}
   * @memberof IPaymentMethodManager
   */
  listPaymentMethods(): IPaymentMethod[];

  /**
   * Tìm phương thức thanh toán bằng key
   *
   * @param {string} key
   * @return {*}  {(IPaymentMethod | undefined)}
   * @memberof IPaymentMethodManager
   */
  getPaymentMethodByKey(key: string): IPaymentMethod | undefined;

  /**
   * Tìm phương thức thanh toán bằng tên
   *
   * @param {string} name
   * @return {*}  {(IPaymentMethod | undefined)}
   * @memberof IPaymentMethodManager
   */
  getPaymentMethodByName(name: string): IPaymentMethod | undefined;

  /**
   * Có tồn tại hay không một phương thức thanh toán với key
   *
   * @param {string} key
   * @return {*}  {boolean}
   * @memberof IPaymentMethodManager
   */
  constrainKey(key: string): boolean;
}
