import { IPartnerTag } from "../partner/partner.entity";

export interface IPartnerTagManager {
  /**
   * Tạo tag CTV mới
   *
   * @param {IPartnerTag} partnerTag
   * @return {*}  {IPartnerTag}
   * @memberof IPartnerTagManager
   */
  createPartnerTag(partnerTag: IPartnerTag): IPartnerTag;

  /**
   * Cập nhật CTV tag
   *
   * @param {IPartnerTag} partnerTag
   * @return {*}  {IPartnerTag}
   * @memberof IPartnerTagManager
   */
  updatePartnerTag(partnerTag: IPartnerTag): IPartnerTag;

  /**
   * Lấy danh sách toàn bộ CTV tag
   *
   * @return {*}  {IPartnerTag[]}
   * @memberof IPartnerTagManager
   */
  listPartnerTags(): IPartnerTag[];

  /**
   * Kiểm tra xem có policy nào dính với CTV tag này không?
   *
   * @param {IPartnerTag} partnerTag
   * @return {*}  {boolean}
   * @memberof IPartnerTagManager
   */
  hasPolicyLinkWithPartnerTag(partnerTag: IPartnerTag): boolean;

  /**
   * Xóa CTV tag
   *
   * @param {IPartnerTag} partnerTag
   * @memberof IPartnerTagManager
   */
  deletePartnerTag(partnerTag: IPartnerTag): void;
}
