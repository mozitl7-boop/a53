import { IPartner } from "../partner/partner.entity";

export interface IPartnerManager {
  /**
   * Tạo một CTV mới
   *
   * @param {IPartner} partner
   * @param {*} contractFile
   * @return {*}  {IPartner}
   * @memberof IPartnerManager
   */
  createPartner(partner: IPartner, contractFile: any): IPartner;

  /**
   * Cập nhật một CTV, nếu không uploadFile thì không cập nhật hợp đồng
   *
   * @param {IPartner} partner
   * @param {*} contractFile
   * @return {*}  {IPartner}
   * @memberof IPartnerManager
   */
  updatePartner(partner: IPartner, contractFile?: any): IPartner;

  /**
   * Get một CTV bằng id
   *
   * @param {number} id
   * @return {*}  {(IPartner | undefined)}
   * @memberof IPartnerManager
   */
  getPartnerById(id: number): IPartner | undefined;

  /**
   * Danh sách CTV
   *
   * @return {*}  {IPartner[]}
   * @memberof IPartnerManager
   */
  listPartners(): IPartner[];

  /**
   * Xóa CTV
   *
   * @param {IPartner} partner
   * @memberof IPartnerManager
   */
  deletePartner(partner: IPartner): void;
}
