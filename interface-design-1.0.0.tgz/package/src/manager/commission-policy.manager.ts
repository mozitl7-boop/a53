import { ICommissionPolicy } from "../commission/commission";
import { IPolicy } from "../policy";

export interface ICommissionPolicyManager {
  /**
   * Tạo chính sách hoa hồng mới
   *
   * @param {IPolicy} policy
   * @param {ICommissionPolicy} commissionPolicy
   * @return {*}  {ICommissionPolicy}
   * @memberof ICommissionPolicyManager
   */
  createCommissionPolicy(policy: IPolicy, commissionPolicy: ICommissionPolicy): ICommissionPolicy;

  /**
   * Cập nhật chính sách hoa hồng
   *
   * @param {ICommissionPolicy} commissionPolicy
   * @return {*}  {ICommissionPolicy}
   * @memberof ICommissionPolicyManager
   */
  updateCommissionPolicy(commissionPolicy: ICommissionPolicy): ICommissionPolicy;

  /**
   * Get danh sách chính sách hoa hồng của một policy nào đó
   *
   * @param {number} policyId
   * @return {*}  {ICommissionPolicy[]}
   * @memberof ICommissionPolicyManager
   */
  listCommissionPoliciesByPolicy(policyId: number): ICommissionPolicy[];

  /**
   * Get một chính sách hoa hồng
   *
   * @param {number} id
   * @return {*}  {ICommissionPolicy}
   * @memberof ICommissionPolicyManager
   */
  getCommissionPolicy(id: number): ICommissionPolicy | undefined;

  /**
   * Xóa chính sách hoa hồng
   *
   * @param {ICommissionPolicy} commissionPolicy
   * @memberof ICommissionPolicyManager
   */
  deleteCommissionPolicy(commissionPolicy: ICommissionPolicy): void;
}
