import { IVoucher } from "../voucher/voucher.entity";

export interface IVoucherManager {
  /**
   * Tạo voucher mới
   *
   * @param {IVoucher} voucher
   * @return {*}  {IVoucher}
   * @memberof IVoucherManager
   */
  createVoucher(voucher: IVoucher): IVoucher;

  /**
   * Cập nhật thông tin voucher
   *
   * @param {IVoucher} voucher
   * @return {*}  {IVoucher}
   * @memberof IVoucherManager
   */
  updateVoucher(voucher: IVoucher): IVoucher;

  /**
   * Danh sách voucher
   *
   * @return {*}  {IVoucher[]}
   * @memberof IVoucherManager
   */
  listVouchers(): IVoucher[];

  /**
   * Xóa voucher
   *
   * @param {IVoucher} voucher
   * @memberof IVoucherManager
   */
  deleteVoucher(voucher: IVoucher): void;
}
