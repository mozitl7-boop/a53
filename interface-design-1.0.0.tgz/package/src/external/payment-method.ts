/**
 * Phương thức thanh toán
 *
 * @export
 * @interface IPaymentMethod
 */
export interface IPaymentMethod {
  key: string;
  name: string;
}
