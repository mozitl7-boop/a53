
/**
 * FIDT User
 *
 * @export
 * @interface IFidtUser
 */
export interface IFidtUser {
  id: string;
}
