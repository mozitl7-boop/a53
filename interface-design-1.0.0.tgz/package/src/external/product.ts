
/**
 * Sản phẩm
 *
 * @export
 * @interface IProduct
 */
export interface IProduct {
  id: number;
}
