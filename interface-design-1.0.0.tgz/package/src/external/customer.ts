/**
 * Khách hàng
 *
 * @export
 * @interface ICustomer
 */
export interface ICustomer {
  id: number;
}

/**
 * Customer Segmentation
 *
 * @export
 * @interface ICustomerSegmentation
 */
export interface ICustomerSegmentation {
  id: number;
  tag: string;
  customers: ICustomer[];
}
