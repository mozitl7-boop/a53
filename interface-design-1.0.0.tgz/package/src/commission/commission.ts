import { ICustomerSegmentation } from "../external/customer";
import { IPartnerTag } from "../partner/partner.entity";
import { IProduct } from "../external/product";
import { IPaymentMethod } from "../external/payment-method";

/**
 * Hoa hồng
 *
 * @export
 * @interface ICommissionPolicy
 */
export interface ICommissionPolicy {
  id: number;

  startDate: Date;
  endDate: Date;

  paymentMethods: IPaymentMethod[];
  customerSegmentation: ICustomerSegmentation[];
  product: IProduct[];
  partnerTags: IPartnerTag[];

  formula: IFormula;
  formulaValue: IFormulaValue[];

  /**
   * Kiểm tra startDate + endDate có hợp lệ không
   *
   * @return {*}  {boolean}
   * @memberof ICommissionPolicy
   */
  checkDateIsValid(): boolean;

  // TODO: tính ở mô?
  /**
   * Tính số tiền hoa hồng
   *
   * @return {*}  {number}
   * @memberof ICommissionPolicy
   */
  calculateCommission(): number;
}

/**
 * Công thức
 *
 * @export
 * @interface IFormula
 */
export interface IFormula {
  id: number;
  key: string;
  name: string;
  params: IFormulaParam[];
}

/**
 * Tham số của công thức
 *
 * @export
 * @interface IFormulaParam
 */
export interface IFormulaParam {
  key: string;
  name: string;
}

export interface IFormulaValue {
  param: IFormulaParam;

  value: number;
}
