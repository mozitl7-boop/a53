
export interface IServiceBase<T, ID> {
  create(entity: T): Promise<T>;
  update(entity: T): Promise<T>;
  get(id: ID): Promise<T | undefined>;
  query(q: string): Promise<T[] | undefined>;
  delete(id: ID): Promise<boolean>;
}
