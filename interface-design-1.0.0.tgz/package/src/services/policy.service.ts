import { IPolicy } from "../policy";
import { IServiceBase } from "./base";

export interface IPolicyService extends IServiceBase<IPolicy, number> {
  // Kiểm tra tồn tại tên policy hay chưa -> chia thanh 2 case CREATE / UPDATE

  /**
   * Upload file vào storage
   *
   * @param {*} file
   * @return {*}  Tên file được lưu
   * @memberof IPolicyService
   */
  uploadFile(file: any): Promise<string>;
}
