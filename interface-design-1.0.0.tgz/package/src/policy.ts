import { ICommissionPolicy } from "./commission/commission";
import { IFidtUser } from "./external/fidt-user";
import { IVoucherPolicy } from "./voucher-policy/voucher-policy";

export enum PolicyStatus {
  /**
   * Nháp
   */
  DRAFT = "DRAFT",

  /**
   * Chờ duyệt
   */
  TO_BE_REVIEWED = "TO_BE_REVIEWED",

  /**
   * Đã được duyệt
   */
  APPROVED = "APPROVED",

  /**
   * Hiện hành
   */
  ON_GOING = "ON_GOING",

  /**
   * Hết hiệu lực
   */
  OUTDATED = "OUTDATED"
};

export interface IPolicyRevisions {
  id: number;

  revisions: IPolicy[];
}

export interface IPolicy {
  id: number;

  /**
   * Phiên bản
   *
   * @type {number}
   * @memberof IPolicy
   */
  revision: number;

  name: string;
  fileUrl: string;

  createdAt: Date;
  lastUpdatedAt: Date;

  createdBy: IFidtUser;
  reviewedBy: IFidtUser;

  status: PolicyStatus;

  voucherPolicies: IVoucherPolicy[];
  commissionPolicies: ICommissionPolicy[];

  /**
   * Tạo ra 1 policy mới (copy toàn bộ voucherPolicies, commissionPolicies, ...)
   *
   * @return {*}  {IPolicy}
   * @memberof IPolicy
   */
  clone(): IPolicy;

  /**
   * Vô hiệu hóa chính sách
   *
   * @memberof IPolicy
   */
  disablePolicy(): void;

  /**
   * Hủy chính sách
   *
   * @memberof IPolicy
   */
  cancelPolicy(): void;

  /**
   * Duyệt chính sách
   *
   * @param {IFidtUser} user
   * @memberof IPolicy
   */
  approvePolicy(user: IFidtUser): void;
}
