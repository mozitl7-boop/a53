import { ICommissionPolicy } from "../commission/commission";
import { ICustomer } from "../external/customer";
import { IPartner } from "../partner/partner.entity";
import { IProduct } from "../external/product";
import { IPromotion } from "../voucher-policy/promotion/promotion.interface";
import { IVoucherPolicy } from "../voucher-policy/voucher-policy";

export enum VoucherType {
  // Cá nhân
  PRIVATE = "PRIVATE",

  // Công khai
  PUBLIC = "PUBLIC"
}

export enum VoucherStatus {
  AVAILABLE = "AVAILABLE",
  HIDE = "HIDE",
  UNAVAILABLE = "UNAVAILABLE",
  INVALID = "INVALID"
}

// TODO: Thiếu nhiều trường
export interface IVoucher {
  id: number;

  voucherCode: string;

  promotion: IPromotion;
  product: IProduct[];
  quantity: number;
  expiredDate: Date;
  voucherType: VoucherType;

  partner: IPartner;

  status: VoucherStatus;
}

export enum VoucherAppliedHistoryAction {
  CREATE = "CREATE",
  UPDATE = "UPDATE",
  DELETE = "DELETE"
}

export interface VoucherAppliedHistory {
  voucher: IVoucher;
  
  customer: ICustomer;
  action: VoucherAppliedHistoryAction;
  createdDate: Date;
  partner: IPartner;
  oldData: string;
  newData: string;
}
