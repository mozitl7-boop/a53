"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoucherAppliedHistoryAction = exports.VoucherStatus = exports.VoucherType = void 0;
var VoucherType;
(function (VoucherType) {
    // Cá nhân
    VoucherType["PRIVATE"] = "PRIVATE";
    // Công khai
    VoucherType["PUBLIC"] = "PUBLIC";
})(VoucherType = exports.VoucherType || (exports.VoucherType = {}));
var VoucherStatus;
(function (VoucherStatus) {
    VoucherStatus["AVAILABLE"] = "AVAILABLE";
    VoucherStatus["HIDE"] = "HIDE";
    VoucherStatus["UNAVAILABLE"] = "UNAVAILABLE";
    VoucherStatus["INVALID"] = "INVALID";
})(VoucherStatus = exports.VoucherStatus || (exports.VoucherStatus = {}));
var VoucherAppliedHistoryAction;
(function (VoucherAppliedHistoryAction) {
    VoucherAppliedHistoryAction["CREATE"] = "CREATE";
    VoucherAppliedHistoryAction["UPDATE"] = "UPDATE";
    VoucherAppliedHistoryAction["DELETE"] = "DELETE";
})(VoucherAppliedHistoryAction = exports.VoucherAppliedHistoryAction || (exports.VoucherAppliedHistoryAction = {}));
