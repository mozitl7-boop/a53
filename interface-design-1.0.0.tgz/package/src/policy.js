"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PolicyStatus = void 0;
var PolicyStatus;
(function (PolicyStatus) {
    /**
     * Nháp
     */
    PolicyStatus["DRAFT"] = "DRAFT";
    /**
     * Chờ duyệt
     */
    PolicyStatus["TO_BE_REVIEWED"] = "TO_BE_REVIEWED";
    /**
     * Đã được duyệt
     */
    PolicyStatus["APPROVED"] = "APPROVED";
    /**
     * Hiện hành
     */
    PolicyStatus["ON_GOING"] = "ON_GOING";
    /**
     * Hết hiệu lực
     */
    PolicyStatus["OUTDATED"] = "OUTDATED";
})(PolicyStatus = exports.PolicyStatus || (exports.PolicyStatus = {}));
;
