import { IFidtUser } from "../external/fidt-user";

export enum IPartnerStatus {

}

/**
 * Cộng tác viên
 *
 * @export
 * @interface IPartner
 */
export interface IPartner {
  id: number;

  fidtUser: IFidtUser;

  fullName: string;
  phoneNumber: string;
  email: string;

  corporationAt: Date;

  status: IPartnerStatus;

  contractFile: string;

  tags: IPartnerTag[];
}

/**
 * Tag cộng tác viên
 *
 * @export
 * @interface IPartnerTag
 */
export interface IPartnerTag {
  id: number;
  tag: string;
  description: string;
  partners: IPartner[];
}
