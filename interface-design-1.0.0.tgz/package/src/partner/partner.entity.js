"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IPartnerStatus = void 0;
var IPartnerStatus;
(function (IPartnerStatus) {
})(IPartnerStatus = exports.IPartnerStatus || (exports.IPartnerStatus = {}));
