import { IPartner } from "../partner/partner.entity";
import { IPaymentMethod } from "../external/payment-method";
import { IProduct } from "../external/product";
import { IVoucher } from "../voucher/voucher.entity";

export enum PaymentStatus {
  NEW = "NEW",

  IN_PROGRESS = "IN_PROGRESS",

  SUCCESS = "SUCCESS",

  CANCEL = "CANCEL"
}

export enum OrderForControlStatus {
  UNPAID = "UNPAID",

  COMPLAIN = "COMPLAIN",

  PAID = "PAID"
}

export interface IOrder {
  id: number;

  code: string;

  paymentMethod: IPaymentMethod;
  paymentStatus: PaymentStatus;
  forControl: OrderForControlStatus;

  commission: number;

  customerFullName: string;
  customerPhone: string;
  customerEmail: string;

  // số tiền thanh toán
  customerPay: number;

  product: IProduct;
  listingProductPrice: number;
  price: number;

  partner: IPartner | undefined;

  createdAt: Date;

  exportVAT: boolean;

  vouchers: IVoucher;
}

export enum OrderAppliedHistoryAction {
  CREATE = "CREATE",
  UPDATE = "UPDATE",
  DELETE = "DELETE"
}

export interface OrderAppliedHistory {
  order: IOrder;
  
  action: OrderAppliedHistoryAction;
  createdDate: Date;
  oldData: string;
  newData: string;
}
