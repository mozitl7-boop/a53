"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderAppliedHistoryAction = exports.OrderForControlStatus = exports.PaymentStatus = void 0;
var PaymentStatus;
(function (PaymentStatus) {
    PaymentStatus["NEW"] = "NEW";
    PaymentStatus["IN_PROGRESS"] = "IN_PROGRESS";
    PaymentStatus["SUCCESS"] = "SUCCESS";
    PaymentStatus["CANCEL"] = "CANCEL";
})(PaymentStatus = exports.PaymentStatus || (exports.PaymentStatus = {}));
var OrderForControlStatus;
(function (OrderForControlStatus) {
    OrderForControlStatus["UNPAID"] = "UNPAID";
    OrderForControlStatus["COMPLAIN"] = "COMPLAIN";
    OrderForControlStatus["PAID"] = "PAID";
})(OrderForControlStatus = exports.OrderForControlStatus || (exports.OrderForControlStatus = {}));
var OrderAppliedHistoryAction;
(function (OrderAppliedHistoryAction) {
    OrderAppliedHistoryAction["CREATE"] = "CREATE";
    OrderAppliedHistoryAction["UPDATE"] = "UPDATE";
    OrderAppliedHistoryAction["DELETE"] = "DELETE";
})(OrderAppliedHistoryAction = exports.OrderAppliedHistoryAction || (exports.OrderAppliedHistoryAction = {}));
