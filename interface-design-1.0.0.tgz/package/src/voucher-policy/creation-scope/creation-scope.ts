import { IPartnerTag } from "../../partner/partner.entity";

/**
 * Phạm vi tạo voucher
 *
 * @export
 * @interface IVoucherCreationScope
 */
export interface IVoucherCreationScope {
  startDate: Date;
  endDate: Date;
  limit: number;

  partnerTags: IPartnerTag[];

// 1: gom chung lại 1 hàm -> validate -> quăng exception, case 2: chia ra từng hàm riêng biệt

  /**
   * Kiểm tra startDate + endDate có hợp lệ không
   *
   * @return {*}  {boolean}
   * @memberof IVoucherCreationScope
   */
  checkDateIsValid(): boolean;

  /**
   * Kiểm tra limit có hợp lệ không
   *
   * @return {*}  {boolean}
   * @memberof IVoucherCreationScope
   */
  checkLimitIsValid(): boolean;
}
