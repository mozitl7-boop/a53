import { IVoucherCreationScope } from "./creation-scope/creation-scope";
import { IPromotion } from "./promotion/promotion.interface";
import { IUsageScope } from "./usage-scope/usage-scope";

/**
 * Chính sách voucher
 *
 * @export
 * @interface IVoucherPolicy
 */
export interface IVoucherPolicy {
  id: number;

  usageScope: IUsageScope;
  voucherCreationScope: IVoucherCreationScope;
  commissions: IPromotion[];
}
