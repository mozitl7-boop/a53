import { IProduct } from "../../external/product";
import { IPromotion } from "./promotion.interface";

export interface IProductBasePromotion extends IPromotion {
  type: "product";
  value: number;
  products: IProduct[];
}
