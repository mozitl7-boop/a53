import { IPromotion } from "./promotion.interface";

export interface IPercentageBasePromotion extends IPromotion {
  type: "percentage";
  value: number;  
}
