import { IPromotion } from "./promotion.interface";

export interface IPriceBasePromotion extends IPromotion {
  type: "price";
  value: number;
}
