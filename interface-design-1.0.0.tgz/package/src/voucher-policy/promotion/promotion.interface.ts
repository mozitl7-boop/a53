import { IProduct } from "../../external/product";

/**
 * Ưu đãi
 *
 * @export
 * @interface IPromotion
 */
export interface IPromotion {
  id: number;

  /**
   * Tên ưu đãi (tiếng việt)
   *
   * @type {string}
   * @memberof IPromotion
   */
  name: string;

  /**
   * Kiểm tra các thông tin trong một ưu đãi có hợp lệ không
   * Ví dụ nếu là product thì số lượng product phải > 0, value > 0
   * Nếu số tiền thì số tiền phải không âm
   *
   * @return {*}  {boolean}
   * @memberof IPromotion
   */
  isValid(): boolean;
}
