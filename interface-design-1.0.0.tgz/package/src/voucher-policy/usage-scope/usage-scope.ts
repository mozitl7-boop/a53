import { ICustomerSegmentation } from "../../external/customer";
import { IProduct } from "../../external/product";
import { IPaymentMethod } from "../../external/payment-method";

/**
 * Phạm vi sử dụng
 *
 * @export
 * @interface IUseScope
 */
export interface IUsageScope {
  startDate: Date;
  endDate: Date;

  limit: number;

  customerSegments: ICustomerSegmentation[];
  paymentMethods: IPaymentMethod[];
  products: IProduct[];

  /**
   * Kiểm tra startDate + endDate có hợp lệ không
   *
   * @return {*}  {boolean}
   * @memberof IUsageScope
   */
  checkDateIsValid(): boolean;

  /**
   * Kiểm tra số lượng tối đa có hợp lệ không
   *
   * @return {*}  {boolean}
   * @memberof IUsageScope
   */
  checkLimitIsValid(): boolean;
}
